package Model;

public interface HitungHarga {
    public float HitungHarga(int hargaPerKg,float berat);
}
